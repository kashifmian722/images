<div class="d-flex bs-wizard">
    <div class="col bs-wizard-step" data-wizard="requirements">
        <div class="progress">
            <div class="progress-bar"></div>
        </div>
        <span class="bs-wizard-dot"></span>
    </div>
    <div class="col bs-wizard-step" data-wizard="database">
        <div class="progress">
            <div class="progress-bar"></div>
        </div>
        <span class="bs-wizard-dot"></span>
    </div>
    <div class="col bs-wizard-step" data-wizard="settings">
        <div class="progress">
            <div class="progress-bar"></div>
        </div>
        <span class="bs-wizard-dot"></span>
    </div>
    <div class="col bs-wizard-step" data-wizard="install">
        <div class="progress">
            <div class="progress-bar"></div>
        </div>
        <span class="bs-wizard-dot"></span>
    </div>
    <div class="col bs-wizard-step" data-wizard="proceed">
        <div class="progress">
            <div class="progress-bar"></div>
        </div>
        <span class="bs-wizard-dot"></span>
    </div>
    <div class="px-2 bs-wizard-step" data-wizard="proceed">
        <span class="bs-wizard-dot"></span>
    </div>
</div>
